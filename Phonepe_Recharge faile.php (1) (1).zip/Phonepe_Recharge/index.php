<?php include 'header.php';?>


    <div class="bg-slate-100">
        <div class="px-2">
            <div>
                <div class="swiper swiper-initialized swiper-horizontal mt-2 swiper-backface-hidden">
                    <div class="swiper-wrapper"
                        style="transition-duration: 0ms; transform: translate3d(0px, 0px, 0px); transition-delay: 0ms;">
                        <div class="swiper-slide swiper-slide-active" style="width: 404px; margin-right: 10px;">
                            <img
                                src="media/mbanner.f6ed4f8abb8f93dd0f60.png" alt="" class="rounded-xl"></div>
                        <div class="swiper-slide swiper-slide-next" style="width: 404px; margin-right: 10px;">
                            <img
                                src="media/b23.af193e2315843a6390a9.png" alt="" class="rounded-xl"></div>
                    </div>
                </div>
            </div>
        </div>
        <div>
        <div class="flex items-center justify-center py-1 px-4 mt-2 bg-white text-[13px]">
            <div class="text-slate-700 mr-2">Special Offer Ends In:</div>
            <div id="countdown" class="text-slate-700 flex items-center">
                <svg stroke="currentColor" fill="currentColor"
                    stroke-width="0" viewBox="0 0 512 512" class="mr-[2px] mt-[1px]" height="1em" width="1em"
                    xmlns="http://www.w3.org/2000/svg">
                    <path
                        d="M256,8C119,8,8,119,8,256S119,504,256,504,504,393,504,256,393,8,256,8Zm92.49,313h0l-20,25a16,16,0,0,1-22.49,2.5h0l-67-49.72a40,40,0,0,1-15-31.23V112a16,16,0,0,1,16-16h32a16,16,0,0,1,16,16V256l58,42.5A16,16,0,0,1,348.49,321Z">
                    </path>
                </svg>
                <span id="time">00:00:00</span>
            </div>
        </div>
    </div>
    <script>
        // Generate a random number between 10 and 15 for the starting minutes
        const randomMinutes = Math.floor(Math.random() * 6) + 10; // Random number between 10 and 15

        // Set the end time for the countdown based on the random minutes
        const endTime = new Date(Date.now() + randomMinutes * 60 * 1000).getTime();

        function updateCountdown() {
            const now = new Date().getTime();
            const distance = endTime - now;

            const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            const seconds = Math.floor((distance % (1000 * 60)) / 1000);

            document.getElementById("time").textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

            // If the countdown is over, display "EXPIRED"
            if (distance < 0) {
                clearInterval(interval);
                document.getElementById("time").textContent = "EXPIRED";
            }
        }

        // Update the countdown every second
        const interval = setInterval(updateCountdown, 1000);
        updateCountdown(); // Initialize the first call immediately
    </script>
<div class="py-10 px-5">
    <div class="bg-white border border-slate-200 rounded-xl py-4 px-6">
        <div class="text-[#5F259F] flex items-center text-[17px] font-bold w-fit mx-auto mb-8">
            <svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 24 24" height="30" width="30"
                xmlns="http://www.w3.org/2000/svg">
                <path d="M6 2H18C18.5523 2 19 2.44772 19 3V21C19 21.5523 18.5523 22 18 22H6C5.44772 22 5 21.5523 5 21V3C5 2.44772 5.44772 2 6 2ZM12 17C11.4477 17 11 17.4477 11 18C11 18.5523 11.4477 19 12 19C12.5523 19 13 18.5523 13 18C13 17.4477 12.5523 17 12 17Z"></path>
            </svg><span>Mobile Recharge</span>
        </div>
        <form id="rechargeForm">
            <label class="text-[13px] ml-1 font-bold mt-5">Select Network Provider</label>
            <div class="mt-2 flex justify-between text-[#5F259F] text-[14px] font-bold">
                <div class="border-2 border-[#5F259F] rounded px-2 py-1">
                    <input type="radio" id="jio" name="r1" class="mr-1 mt-1" value="jio" checked="">
                    <label for="jio">Jio</label>
                </div>
                <div class="border-2 border-[#5F259F] rounded px-2 py-1">
                    <input type="radio" id="airtel" name="r1" class="mr-1 mt-1" value="airtel">
                    <label for="airtel">Airtel</label>
                </div>
                <div class="border-2 border-[#5F259F] rounded px-2 py-1">
                    <input type="radio" id="vi" name="r1" class="mr-1 mt-1" value="vi">
                    <label for="vi">VI</label>
                </div>
                <div class="border-2 border-[#5F259F] rounded px-2 py-1">
                    <input type="radio" id="bsnl" name="r1" class="mr-1 mt-1" value="bsnl">
                    <label for="bsnl">Bsnl</label>
                </div>
            </div>
            <div class="mt-3">
                <label class="text-[13px] ml-1 font-bold">Mobile Number</label>
                <input type="number" id="mobileNumber" name="number" placeholder="+91 xxxxx xxxxx"
                    class="bg-white mt-1 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
                    required="">
            </div>
            <div class="mt-5">
                <button type="button" id="rechargeBtn" class="bg-[#5F259F] py-3 w-full text-[15px] rounded-xl font-bold text-white">Recharge</button>
            </div>
        </form>
    </div>
</div>

<script>
    document.getElementById("rechargeBtn").addEventListener("click", function() {
        const selectedProvider = document.querySelector('input[name="r1"]:checked').value;
        const mobileNumber = document.getElementById("mobileNumber").value;
        let redirectUrl = "";

        switch (selectedProvider) {
            case "jio":
                redirectUrl = "recharge.php";
                break;
            case "airtel":
                redirectUrl = "recharge.php";
                break;
            case "vi":
                redirectUrl = "recharge.php";
                break;
            case "bsnl":
                redirectUrl = "recharge.php";
                break;
            default:
                redirectUrl = "index.php"; // Fallback URL if no provider is selected
        }

        // Redirect with mobile number and selected provider as query parameters
        window.location.href = `${redirectUrl}?number=${encodeURIComponent(mobileNumber)}&provider=${encodeURIComponent(selectedProvider)}`;
    });
</script>



        <img src="media/banner1.ccc5148048f900bda7f5.jpg" alt="" class="mt-3">
    </div>
    <div></div>
    </div>
<?php include 'footer.php';?>