<?php include 'header.php'; ?>

<div style="min-height: 80vh; display: flex; flex-direction: column; justify-content: center; align-items: center; text-align: center; background-color: #f9f9f9; padding: 20px;">
    <h1 style="font-size: 24px; font-weight: bold; color: #c0392b;">Your payment has been failed!</h1>
    <p style="font-size: 16px; color: #555;">Please try again.</p>
    <p style="font-size: 14px; margin-top: 10px; color: #888;">
        <strong>Don't worry!</strong> <br> Your money will be refunded in 7 working days.
    </p>
    <a href="/" style="margin-top: 20px; display: inline-block; padding: 10px 20px; background-color: #5F259F; color: white; border-radius: 8px; text-decoration: none;">Back to Home</a>
</div>


<?php include 'footer.php'; ?>
